#!/bin/sh
######################################################################
# oswnet.sh
# This script is called by OSWatcher.sh. This script runs the two
# netstat commands back to back.
#
######################################################################
PLATFORM=`/bin/uname`

if [ $2 != 0 ]; then
  echo "zzz ***"`date '+%a %b %e %T %Z %Y'` >> $1
else
  echo "zzz ***"`date` >> $1
fi

case $PLATFORM in
    Linux)
      ip -s link >> $1
      nstat -az >> $1
    ;;
    *)
      netstat -a -i -n >> $1
      netstat -s >> $1      
    ;;
esac 

rm locks/netlock.file
