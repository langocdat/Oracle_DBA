
######################################################################
# RAC TRACEROUTE AUTOMATION README:
######################################################################

# To turn on automatic data collection for private networks the user must 
# meet the following pre-requisites:

# Ensure PATH environment variable is set properly to locate the traceroute 
# utility and other OS utilities.

# Ensure Passwordless ssh is working on all RAC nodes for OSWatcher user
# For more details on configuring passwordless ssh refer to note 300548.1.

# Ensure OSWatcher is configured and started as user owning Oracle Clusterware 
#software only. 

# CRS stack must be up and running before OSwatcher is installed and started
# the first time.
# When OSWatcher is configured and started for first time, private.net is 
# created in oswbb directory.
# This file contains entries for running the traceroute command to verify 
# RAC private networks.
  
# If private Network configuration gets changed then remove the private.net file. 
# The file will get created at next snapshot interval.

# Check the standard output or nohup.out for any success/failure/warnings 
# messages and correct it.

# Kindly Note: 

# Traceroute automation is best designed to work on 11.2 and 12c Oracle Clusterware.
# It may not work for pre 11.2 Oracle Clusterware.
# In such cases, you need to manually configure private.net as per OSWatcher README.

# Traceroute Automation will not work for pre 11.2 Oracle Clusterware on SunOS 
# using ipmp for Private Interconnect.
# For more details about the pre 11.2 configuration for the cluster interconnect 
# if IPMP is used, refer to note (368464.1).
# In such cases, you need to manually configure private.net as per OSWatcher README.

# To manually configure private.net, please refer OSWatcher README in (note 301137.1).

######################################################################