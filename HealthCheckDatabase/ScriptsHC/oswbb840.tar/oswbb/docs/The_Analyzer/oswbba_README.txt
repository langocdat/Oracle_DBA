######################################################################
######################################################################
# Copyright (c)  2017 by Oracle Corporation
######################################################################
# Modifications Section:
######################################################################
##     Date        File                  Changes
######################################################################
##  09/18/2006                           Baseline version 2.0.4 
##
##  09/18/2007     oswgraph.java         Added user interface        
##  V2.1.0	   OSWParser.java        enhancements, AIX io graphs,
##                 ProcessObject.java    html profiler
##                 SortObject.java
##                 GraphObject.java
##                 ContainerObject.java
##                 FileObjects.java
##
##  02/12/2008     OSWParser.java        Fixed problem reading AIX        
##  V2.1.2	                         iostat files   
##  07/31/2009     OSWatcher.sh          Release 3.0 for EXADATA
##  V3.0.0                                  
##  02/11/11       OSWParser.java        Fixed Linux bug for entries
##  V3.0.1                               spanning multiple lines
##  05/04/11                             Fixed directory permission on
##  V3.0.2                               install of osw.tar
##  02/01/12                             Release 4.0 oswbba
##  V4.0.0
##  06/18/12                             Release 5.0 oswbba
##  V5.0.0
##  V5.1.0                          added nfs collection
##                                  for Linux
##  V5.1.1         oswbba,jar       Ignore compressed files
##  08/22/12                        when analyzing
##  V5.1.2         oswbba.jar       ignore duplicate iostat entries
##  10/26/12                        for same i/o device
##  V5.2.0         oswbba.jar       Multiple bug fix release
##  11/7/12                         fix vmstat inserting corrupt data
##                 oswbba.jar       fix Linux memory status = unknown
##  V6.0.0                          Release 6.0 oswbba
##  02/11/13       oswbba.jar
##  V7.0.0                          Release 7.0 oswbba
##  10/17/13       oswbba.jar
##  V7.1.0                          Release 7.1 oswbba
##  01/14/14       oswbba.jar
##  V7.1.1                          fixed problem with parsing of
##  01/14/14       oswbba.jar       ps data (taking too long)
##  V7.1.2                          fixed bug with prstat (SUN only)
##  02/18/14       oswbba.jar
##  V7.1.3                          fixed bug with iostat (AIX only)
##  02/27/14       oswbba.jar
##  V7.2.0                          Release 7.2 oswbba
##  04/29/14       oswbba.jar
##  V7.3.0                          Release 7.3 oswbba
##  05/28/14       oswbba.jar
##  V7.3.1                          Release 7.3.1 oswbba
##  09/05/14       oswbba.jar
##  V8.0.0                          Release 8.0.0 oswbba
##  04/19/17       oswbba.jar
##  V8.1.0                          Release 8.1.0 oswbba
##  08/25/17       oswbba.jar
##  V8.1.3                          Release 8.1.3                         
##  02/15/19       oswbba.jar       pidstat analysis
##                                  process profiling
##  V8.2.0                          Release 8.2.0                        
##  05/06/19       oswbba.jar       pidstat analysis
##                                  process profiling
##  V8.3.0                          Release 8.3.0                        
##  07/16/19       oswbba.jar              
##  v8.4.0         oswbba.jar       Release 8.4.0
##  11/16/19                        Updates to analyzer 
##                                                    
######################################################################
Version 8.4.0 New Features
######################################################################

WHAT'S NEW IN THIS RELEASE:

Enhanced hang analysis in sections 2.0 and 2.1 
New traceroute analysis section 7.5 
Private interconnect tab on Dashboard Network 
Percent Free Memory Graph on Dashboard 
CPU Utilization Graph on Dashboard 
Multiple bug fixes.

See /docs/OSWatcherOverview_840.pdf for details.

######################################################################
# UNIX Checklist:
######################################################################

This utility requires an X-Windows client to run.

######################################################################
# Java Checklist:
######################################################################

This release of oswbba requires java 8.0 or higher!

Before running this tool, make sure you have java installed on your 
system. Java can be downloaded from https://www.java.com/en/download/ 

To verify you have java installed on your system issue the following 
command...

$java -version

Attention Linux users. Linux does NOT come shipped with java, If you
run the java -version command and you see a version number returned
and see the word "FREE" it means java is not really installed. You 
must download and install java or use the version that comes shipped
with Oracle.

Linux Example (java not really installed)

java -version

java version "1.4.0"
gij (GNU libgcj) version 4.1.2 20080704 (Red Hat 4.1.2-44)

Copyright (C) 2006 Free Software Foundation, Inc.
This is free software; see the source for copying conditions.  There
is NO warranty; not even for MERCHANTABILITY or FITNESS FOR A 
PARTICULAR PURPOSE.

Alternatively, you can use the version of java that comes shipped
with ORACLE. Here is an example of using the version of java that 
comes shipped with the database...
(Depending upon the version of the database the jre may be in a 
different location). In version 10, the location of java is in the
directory $ORACLE_HOME/jre/1.4.2/bin  

Now put this location in the UNIX PATH variable
export PATH=$ORACLE_HOME/jre/1.4.2/bin:$PATH

######################################################################
# Linux Users Only:
######################################################################

Due to a licensing issue with Linux, most Linux systems will not have 
java installed but simply a placeholder which can be confusing. You 
should either download java or use the version of java which comes 
shipped with ORACLE.

######################################################################
# RAC Users Only:
######################################################################

A separate archive directory is required for each node in the cluster. 
For shared file systems this would require a separate unique named
archive directory for each node. Mixing files from different nodes in 
the same directory structure will result in timestamp errors when
running oswbba.

######################################################################
# Installing oswbba:
######################################################################

oswbba is installed by default when OSWatcher is installed.

######################################################################
# User Guide:
######################################################################

Please refer to the user guide contained in this docs directory for
instructions on how to use oswbba.

